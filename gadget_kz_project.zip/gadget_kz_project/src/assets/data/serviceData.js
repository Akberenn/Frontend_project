const serviceData = [
  {
    icon: "ri-truck-line",
    title: "Free Shipping",
    subtitle: "Around the city of Almaty",
    bg: "#fdefe6",
  },
  {
    icon: "ri-refresh-line",
    title: "Easy Returns",
    subtitle: "Always properly observed",
    bg: "#ceebe9",
  },
  {
    icon: "ri-secure-payment-line",
    title: "Secure Payment",
    subtitle: "99% guarantee for this",
    bg: "#e2f2b2",
  },
  {
    icon: "ri-exchange-dollar-line",
    title: " Back Guarantee",
    subtitle: "100% guarantee for this",
    bg: "#d6e5fb",
  },
];

export default serviceData;
