import React,{useState} from "react";
import Helment from "../components/Helment/Helment";
import {Container,Row,Col}from "reactstrap";
import CommonSection from "../components/UI/CommonSection";
import '../styles/shop.css'
import products from "../assets/data/products";
import ProductsList from "../components/UI/ProductsList";
const Shop = () =>{
    const [productsData, setProductsData] = useState(products);
    const handleFilter = (e) => {
        const filterValue = e.target.value;
        if (filterValue === "laptop") {
            const filteredProducts = products.filter(
                (item) => item.category === "laptop"
            );
            setProductsData(filteredProducts);
        }
        if (filterValue === "mobile") {
            const filteredProducts = products.filter(
                (item) => item.category === "mobile"
            );
            setProductsData(filteredProducts);
        }
        if (filterValue === "headphone") {
            const filteredProducts = products.filter(
                (item) => item.category === "headphone"
            );
            setProductsData(filteredProducts);
        }
        if (filterValue === "watch") {
            const filteredProducts = products.filter(
                (item) => item.category === "watch"
            );
            setProductsData(filteredProducts);
        }
    };

    const handleSearch = e=> {
        const searchTerm = e.target.value
        const searchedProducts = products.filter(item => item.productName.toLowerCase().includes(searchTerm.toLowerCase()))
        setProductsData(searchedProducts)
    }


        const [sortOption, setSortOption] = useState(""); // State to track the selected sort option

        const handleSortChange = (e) => {
            setSortOption(e.target.value);
            // You can perform the sorting logic here based on the selected option
            // For simplicity, let's just log the selected option for now
            console.log("Selected sort option:", e.target.value);
        };



return (
    <Helment title="Shop">
        <CommonSection title="Products" />

        <section>
            <Container>
                <Row>
                    <Col lg="3" md="3">
                        <div className="filter＿widget">
                            <select onChange={handleFilter}>
                                <option>Filter by Category</option>
                                <option value="laptop">Laptop</option>
                                <option value="mobile">Mobile</option>
                                <option value="headphone">Headphone</option>
                                <option value="watch">Watch</option>
                        </select>
                    </div>
                </Col>
                <Col lg="3" md="6" className="text-end">
                    <div className="filter＿widget">
                        <select value={sortOption} onChange={handleSortChange}>
                            <option>Sort by:</option>
                            <option value="Ascending">Ascending</option>
                            <option value="Descending">Descending</option>

                        </select>
                    </div>
                </Col>
                <Col lg="6" md="12">
                    <div className="search__box">
                        <input type="text" placeholder="Search..." onChange={handleSearch}/>
                        <span>
                            <i className="ri-search-line"></i>
                        </span>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>

        <section className="pt-0 products__section">
            <Container>
                <Row>
                    {
                        productsData.length=== 0? <h1 className="text-center fs-0">No products are found</h1>
                            :<ProductsList data={productsData}/>
                    }
                </Row>
            </Container>
        </section>


</Helment>
) ;
            }

export default Shop;


