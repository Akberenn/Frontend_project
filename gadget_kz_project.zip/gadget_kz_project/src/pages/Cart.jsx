import React from "react";
import {Container,Row,Col} from "reactstrap";
import Helment from "../components/Helment/Helment";
import CommonSection from "../components/UI/CommonSection";
import '../styles/cart.css'
import {motion} from "framer-motion";
import {cartActions} from "../redux/slices/cartSlice";
import {useSelector,useDispatch} from "react-redux";
import {Link} from "react-router-dom";


const Cart =()=> {

    const cartItems=useSelector(state=>state.cart.cartItems)
    const totalAmount=useSelector(state=>state.cart.totalAmount)


    return (
        <Helment title="Card">
            <CommonSection title="Shopping Cart"/>
            <section>
                <Container>
                    <Row>
                        <Col lg="12" >
                            {
                                cartItems.length===0?
                                        <h1 className=" text-center fs-6 text-white">No item added to the cart</h1>:
                                    <table className="table bordered text-white">
                                        <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Title</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Delete</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        {
                                            cartItems.map((item,index)=>(
                                                <Tr item={item} key={index}/>
                                            ))
                                        }
                                        </tbody>


                                    </table>

                            }


                        </Col>
                        <Col lg='3'>
                            {/*<div>*/}
                            {/*    <h6>Subtotal</h6>*/}
                            {/*    <span>{totalAmount}KZT</span>*/}
                            {/*</div>*/}
                            {/*<p>taxes and shipping will calculate in checkout</p>*/}
                            {/*<div>*/}
                            {/*    <button className="buy__btn"><Link to='/shop'>Continue shopping</Link></button>*/}
                            {/*    <button className="buy__btn"><Link to='/checkout'>Checkout</Link></button>*/}

                            {/*</div>*/}
                        </Col>
                    </Row>
                </Container>
            </section>
        </Helment>
    );
};


const Tr = ({ item }) => {
    const dispatch = useDispatch();
    const deleteProduct = () => {
        dispatch(cartActions.deleteItem(item.id));
    };

    return (
        <tr>
            <td>
                <img src={item.imgUrl} alt="" />
            </td>
            <td>{item.productName}</td>
            <td>{item.price}</td>
            <td>{item.quantity}</td>
            <td>
                <motion.i
                    whileTap={{ scale: 1.2 }}
                    onClick={deleteProduct}
                    className="ri-delete-bin-line"
                ></motion.i>
            </td>
        </tr>
    );
};



export default Cart;


