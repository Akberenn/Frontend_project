import React from "react";
import { Container } from "reactstrap";
import '../../styles/common-section.css';
import shop from '../../assets/images/headphone_black.png';
import shop2 from '../../assets/images/headphone_blue.png';
import shop3 from '../../assets/images/headphone_grey.png';


const CommonSection = ({ title }) => {
    return (
        <section className="common_section">
            <Container className="text-center">
                    <h3>{title}</h3>
            </Container>
        </section>
    );
};

export default CommonSection;
